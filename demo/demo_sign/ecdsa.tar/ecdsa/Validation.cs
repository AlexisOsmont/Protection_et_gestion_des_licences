using EllipticCurve;

string[] arguments = Environment.GetCommandLineArgs();
if (arguments.GetLength(0) != 4)
{
    Console.WriteLine("ecdsa.exe licence signature pubkey");
    return;
}

string? licence = arguments[1];
string? signfile = arguments[2];
string? pubkey = arguments[3];

string publicKeyPem = EllipticCurve.Utils.File.read(pubkey);
byte[] signatureDer = EllipticCurve.Utils.File.readBytes(signfile);
string message = EllipticCurve.Utils.File.read(licence);

PublicKey publicKey = PublicKey.fromPem(publicKeyPem);
Signature signature = Signature.fromDer(signatureDer);

Console.WriteLine("File verification : " + Ecdsa.verify(message, signature, publicKey));
return;